<?php

function amzius(array $arr) {
    foreach ($arr as $person) {
            $age = date("Y") - $person['year'];
            echo 'Nuo ' . $person['name'] . ' gimimo praejo ' . $age . ' metai<br>';
    }   
}
