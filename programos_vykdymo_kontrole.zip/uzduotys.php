<?php

function kintamojo_tipas($i) {

    echo 'Sis kintamasis yra ';
    switch (gettype($i)) {
        case 'string':
            echo "string";
            break;
        case 'integer':
            echo "integer";
            break;
        case 'boolean':
            echo "boolean";
            break;
        case 'float':
            echo "float";
            break;
        case 'object':
            echo "object";
            'break';
        case 'array':
            echo "array";
            break;
        case 'NULL':
            echo "NULL";
            break;
        case 'Resource':
            echo "Resource";
            break;
        default: 
            echo "Nezinomas tipas";
            break;                     
    }

    echo ' tipo<br>';

}

$masyvas = [1,2,3];

kintamojo_tipas(5);
kintamojo_tipas(6.2);
kintamojo_tipas('Programavimas');
kintamojo_tipas(true);
kintamojo_tipas($a);
kintamojo_tipas($masyvas);




$array = [4, 2, 2, 0, 1, 2, 3];
function suma_iki_nelyginio(array $array){ 
    $suma = 0;
    for ($i = 0; $i < count($array); $i++) {
        if ($array[$i] % 2 === 0) {
            $suma += $array[$i];
        } else {
            break;
        }

    }
    echo 'Atsakymas: ' . $suma;
}   

suma_iki_nelyginio($array);

$arr = [4, -2, 2, 0, -1, 2, 3, -5, 4, -6, 3, -4];

function teigiami_i_masyvo_pradzia(array $array){ 
    foreach ($array as $key => $value) {
        if ($value < 0) {
           continue;
        }
        unset($array[$key]); 
        array_unshift($array, $value);     
    }
    var_dump($array);
}   

teigiami_i_masyvo_pradzia($arr);


/*
1. Turime žmonių masyvą, kurio kiekvienas elementas yra
masyvas su žmogaus vardu ir lytimi. Pvz:

$zmones = [
[‘vardas’ => ‘Jonas’, ‘lytis’ => ‘V’],
[‘vardas’ => ‘Ona’, ‘lytis’ => ‘M’],
[‘vardas’ => ‘Petras’, ‘lytis’ => ‘V’],
[‘vardas’ => ‘Marytė’, ‘lytis’ => ‘M’],
[‘vardas’ => ‘Eglė’, ‘lytis’ => ‘M’]
];

Atspausdinkite visas galimas skirtingas poras vyras - moteris.

*/

$zmones = [
    ['vardas' => 'Jonas', 'lytis' => 'V'],
    ['vardas' => 'Ona', 'lytis' => 'M'],
    ['vardas' => 'Petras', 'lytis' => 'V'],
    ['vardas' => 'Marytė', 'lytis' => 'M'],
    ['vardas' => 'Eglė', 'lytis' => 'M']
    ];

foreach ($zmones as $zmogus) {
  if ($zmogus['lytis'] === 'V') {
      foreach ($zmones as $pagalbinis_zmogus) {
          if ($pagalbinis_zmogus['lytis'] === 'V') {
              continue;
          }
          echo $zmogus['vardas'] . ' - ' . $pagalbinis_zmogus['vardas'] . '<br>';
      }
  } 
}

//2. Tie patys duomenys tik sudarome 3 asmenų grupes taip kad nebūtų tų pačių lyčių.




/*
3. Turime mokinių sąrašą su dalykais ir gautais pažymiais už tuos dalykus, pvz.:

$mokiniai = [
[vardas => “Jonas”, pazymiai => [
lietuviu => [4, 8, 6, 7], anglu => [6, 7, 8],
matematika => [3, 5, 4]]],
[vardas => “Ona”, pazymiai => [
lietuviu => [10, 9, 10], anglu => [9, 8, 10],
matematika => [10, 10, 9, 9]]],
... ];

Suskaičiuokite kuris geriausiai mokosi pagal visų dalykų pažymių
vidurkius. Dalyko pažymio nustatymui reikės panaudoti funkciją
round()

*/

$sarasas = 
    [
    ['vardas' => 'Jonas', 'pazymiai' => [
      'lietuviu' => [4, 8, 6, 7],
      'anglu' => [6, 7, 8],
    '  matematika' => [3, 5, 4]]],
    ['vardas' => 'Ona', 'pazymiai' => [
      'lietuviu' => [10, 9, 10],
      'anglu' => [9, 8, 10],
      'matematika' => [10, 10, 9, 9]]],
    ['vardas' => 'Kazys', 'pazymiai' => [
        'lietuviu' => [10, 10, 10],
        'anglu' => [9, 8, 10],
        'matematika' => [10, 7, 9, 9]]]
    ];

//skaiciuojami atskiru pamoku vidurkiai, tada bendras vidurkis, mokinio vardas ir bendras vidurkis ikeliami su raktiniais indeksais i pagalbini masyva
//pagalbinis masyvas ipushinamas i galutini masyva, kuris pushinant gaunasi daugiamatis  

/*
$palyginimui = [];    
foreach ($mokiniai as $mokinys){
    $vidurkiu_suma = 0;
    echo '<br>Mokinio ' . $mokinys['vardas'] . ':<br> ';
    foreach ($mokinys['pazymiai'] as $key => $pamokos){   
        $vidurkis = round(array_sum($pamokos)/count($pamokos),1);
        $vidurkiu_suma += $vidurkis; 
        echo  $key . ' vidurkis yra ' . $vidurkis . '<br>';          
    }
    $bendras = round($vidurkiu_suma / count($mokinys['pazymiai']),1);
    echo 'bendras vidurkis yra: ' . $bendras . '<br>';
    array_push($palyginimui,['vardas' => $mokinys['vardas']],['bendras' => $bendras]);
}

//lyginu reiksmes savo rezultatu masyve

$pagalbinis_masyvas = NULL;
$max = 0;
foreach($palyginimui as $row) {
   if ($max < $row['bendras']) {
       $max = $row['bendras'];
       $geriausias = $row['vardas'];
   }  
}

echo '<br>Isvada: Geresniu mokiniu laikomas ' . $geriausias . ' su vidurkiu ' . $max;

*/

function MokiniuPamokuVidurkiai (array $mokiniai) {   
    foreach ($mokiniai as $mokinys){
        $vidurkiu_suma = 0;
        $informacija = [];
        foreach ($mokinys['pazymiai'] as $key => $pamokos){   
            $vidurkis = round(array_sum($pamokos)/count($pamokos),1);
            $informacija [$key] = $vidurkis;  
        }
        $vidurkiai [$mokinys['vardas']] = $informacija;                           
    }
    return $vidurkiai;
}

function KiekvienoMokinioBendrasVidurkis (array $vidurkiai) {
    foreach ($vidurkiai as $key => $pamokos) {
        var_dump($pamokos);
        $bendras = round(array_sum($pamokos) / count($pamokos),1);   
        $mokinioBendras[$key] = $bendras;
    }   
    return $mokinioBendras;  
}
    
function geriausiasMokinys(array $vidurkiai) {
    $max = 0;
    echo 'Mokiniu vidurkiu sarasas: ' . var_dump($vidurkiai);
    foreach($vidurkiai as $key => $mokinioVidurkis) {
        if ($max < $mokinioVidurkis) {
            $max = $mokinioVidurkis;
            $geriausias = $key;
        }
    }  
    echo 'Geriausias mokinys yra ' . $geriausias . ' su vidurkiu ' . $max;  
} 

    
$dalykuVidurkiai = MokiniuPamokuVidurkiai($sarasas);   
$bendriVidurkiai = KiekvienoMokinioBendrasVidurkis($dalykuVidurkiai);
geriausiasMokinys($bendriVidurkiai);

