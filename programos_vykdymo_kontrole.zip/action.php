<?php

require_once 'arrays.php';
require_once 'functions.php';

amzius($zmoniu_info);
