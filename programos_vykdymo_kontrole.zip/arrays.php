<?php
$zmoniu_info = [
               ['name' => 'Jonas','year' => 1988],
               ['name' => 'Petras','year' => 2000],
               ['name' =>'Zigmas', 'year' => 1964],
               ['name' =>'Martynas', 'year' => 1981],
               ['name' =>'Maryte', 'year' => 1970]
               ]; 